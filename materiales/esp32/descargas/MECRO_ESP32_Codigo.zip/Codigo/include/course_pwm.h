#pragma once
#include <Arduino.h>
#include <esp_arduino_version.h>
// Target: ESP32 classic. Pin and channel are different identifiers.
class CoursePwm {
  uint8_t pin_, channel_;
public:
  CoursePwm(uint8_t pin, uint8_t channel):pin_(pin),channel_(channel){}
  bool begin(uint32_t hz,uint8_t bits) {
#if ESP_ARDUINO_VERSION_MAJOR >= 3
    return ledcAttachChannel(pin_,hz,bits,channel_);
#else
    double actual=ledcSetup(channel_,hz,bits);
    if(actual<=0)return false;
    ledcAttachPin(pin_,channel_);return true;
#endif
  }
  void write(uint32_t duty) {
#if ESP_ARDUINO_VERSION_MAJOR >= 3
    ledcWrite(pin_,duty);
#else
    ledcWrite(channel_,duty);
#endif
  }
};
