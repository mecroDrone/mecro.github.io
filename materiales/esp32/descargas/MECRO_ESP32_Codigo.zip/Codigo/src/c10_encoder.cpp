#include <Arduino.h>
constexpr uint8_t ENCODER_A=32;
// Exercise constant: replace with measured counts at the observed output shaft.
constexpr float COUNTS_PER_OUTPUT_REV=20.0f;
volatile uint32_t edges=0;portMUX_TYPE mux=portMUX_INITIALIZER_UNLOCKED;
void IRAM_ATTR edge(){portENTER_CRITICAL_ISR(&mux);++edges;portEXIT_CRITICAL_ISR(&mux);}
uint32_t last=0;
void setup(){Serial.begin(115200);pinMode(ENCODER_A,INPUT_PULLUP);
 attachInterrupt(digitalPinToInterrupt(ENCODER_A),edge,RISING);last=millis();}
void loop(){uint32_t now=millis();uint32_t elapsed=now-last;if(elapsed<100)return;
  portENTER_CRITICAL(&mux);uint32_t count=edges;edges=0;portEXIT_CRITICAL(&mux);
  last=now;float rpm=60000.0f*count/(COUNTS_PER_OUTPUT_REV*elapsed);
  Serial.printf("%lu,%lu,%lu,%.1f\n",(unsigned long)now,(unsigned long)elapsed,
     (unsigned long)count,rpm);
}
