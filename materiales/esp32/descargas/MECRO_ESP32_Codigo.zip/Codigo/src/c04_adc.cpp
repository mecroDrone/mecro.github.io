#include <Arduino.h>
constexpr uint8_t ADC_PIN=34,LED=23;
uint32_t last=0;bool on=false;
void setup(){Serial.begin(115200);pinMode(LED,OUTPUT);analogReadResolution(12);
  analogSetPinAttenuation(ADC_PIN,ADC_11db);}
void loop(){uint32_t now=millis();if(uint32_t(now-last)<50)return;last=now;
  int raw=analogRead(ADC_PIN);
  // These thresholds are exercise values. Confirm the LDR divider polarity.
  if(raw<1500)on=true;else if(raw>1800)on=false;
  digitalWrite(LED,on);Serial.printf("%lu,%d,%d\n",(unsigned long)now,raw,on);
}
