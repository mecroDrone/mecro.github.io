#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <time.h>
WebServer server(80);uint32_t sampleAt=0;int raw=0;
const char* SSID="Wokwi-GUEST";const char* PASS="";
void setup(){Serial.begin(115200);analogReadResolution(12);WiFi.begin(SSID,PASS);
 configTime(0,0,"pool.ntp.org");
 server.on("/datos",[](){
  String json="{\"t_ms\":"+String(millis())+",\"adc\":"+String(raw)+"}";
  server.send(200,"application/json",json);
 });server.begin();}
void loop(){uint32_t now=millis();
 if(uint32_t(now-sampleAt)>=100){sampleAt=now;raw=analogRead(34);}
 server.handleClient();
 static uint32_t logAt=0;if(uint32_t(now-logAt)>=1000){logAt=now;
  time_t utc=time(nullptr);Serial.printf("%lu,%d,%d,%lld\n",(unsigned long)now,
   raw,int(WiFi.status()),(long long)utc);}
 // Physical board: set local lab Wi-Fi. Wokwi inbound HTTP needs supported gateway.
}
