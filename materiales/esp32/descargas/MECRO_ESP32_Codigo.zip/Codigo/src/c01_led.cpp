#include <Arduino.h>
constexpr uint8_t LED=23; // External LED and series resistor.
uint32_t last=0; bool on=false;
void setup(){pinMode(LED,OUTPUT);Serial.begin(115200);}
void loop(){
  uint32_t now=millis();
  if(uint32_t(now-last)>=500){last=now;on=!on;
    digitalWrite(LED,on);Serial.println(on?"ON":"OFF");}
}
