#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_MPU6050.h>
#include <math.h>
Adafruit_MPU6050 imu;
enum class State:uint8_t{INIT,READY,FAULT};State state=State::INIT;
constexpr uint8_t LED=23,BTN=18;bool ready=false,haveSample=false;
uint32_t sampleAt=0,logAt=0,lastValid=0,seq=0;
float roll=0,pitch=0,gyro=0;
void setup(){Serial.begin(115200);pinMode(LED,OUTPUT);pinMode(BTN,INPUT_PULLUP);
 Wire.begin(21,22);Wire.setTimeOut(20);ready=imu.begin();state=ready?State::READY:State::FAULT;
 Serial.println("seq,t_ms,state,data_valid,roll_deg,pitch_deg,gx_rad_s,adc");}
void loop(){uint32_t now=millis();
 if(ready&&uint32_t(now-sampleAt)>=50){sampleAt=now;sensors_event_t a,g,temp;
  Wire.beginTransmission(0x68);bool ack=Wire.endTransmission()==0;
  if(ack){imu.getEvent(&a,&g,&temp);
  float norm=sqrtf(a.acceleration.x*a.acceleration.x+a.acceleration.y*a.acceleration.y+
                   a.acceleration.z*a.acceleration.z);
  if(isfinite(norm)&&norm>1 && norm<30){
   roll=atan2f(a.acceleration.y,a.acceleration.z)*180.0f/PI;
   pitch=atan2f(-a.acceleration.x,sqrtf(a.acceleration.y*a.acceleration.y+
                   a.acceleration.z*a.acceleration.z))*180.0f/PI;
   gyro=g.gyro.x;lastValid=now;haveSample=true;}}
 }
 bool valid=ready&&haveSample&&uint32_t(now-lastValid)<=250;
 state=valid?State::READY:((ready&&!haveSample&&now<250)?State::INIT:State::FAULT);
 digitalWrite(LED,valid);
 if(uint32_t(now-logAt)>=100){logAt=now;
  Serial.printf("%lu,%lu,%d,%d,%.2f,%.2f,%.3f,%d\n",(unsigned long)seq++,
   (unsigned long)now,int(state),int(valid),roll,pitch,gyro,analogRead(34));}
 // data_valid means recent plausible data, not certified attitude or bus integrity.
 // BTN is reserved for the student's own event/acknowledgement extension.
}
