#include <Arduino.h>
#include <math.h>
// Normalized bench command only. No radio receiver, mixer or motor output.
float axis(int raw,int center){float d=raw-center;if(fabsf(d)<100)return 0;
 return constrain(d/(d>=0?4095.0f-center:float(center)),-1.0f,1.0f);}
uint32_t last=0;
void setup(){Serial.begin(115200);analogReadResolution(12);}
void loop(){uint32_t now=millis();if(uint32_t(now-last)<50)return;last=now;
 float x=axis(analogRead(34),2048),y=axis(analogRead(35),2048);
 Serial.printf("%lu,%.3f,%.3f\n",(unsigned long)now,x,y);
 // 2048 and the deadband are exercise values; measure each physical joystick.
}
