#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_MPU6050.h>
#include <math.h>
Adafruit_MPU6050 imu;bool ready=false;uint32_t last=0;
void setup(){Serial.begin(115200);Wire.begin(21,22);ready=imu.begin();
 if(!ready){Serial.println("IMU_INVALID");return;}
 imu.setAccelerometerRange(MPU6050_RANGE_2_G);imu.setGyroRange(MPU6050_RANGE_250_DEG);
 imu.setFilterBandwidth(MPU6050_BAND_21_HZ);}
void loop(){uint32_t now=millis();if(!ready||uint32_t(now-last)<50)return;last=now;
 sensors_event_t a,g,temp;imu.getEvent(&a,&g,&temp);
 float roll=atan2f(a.acceleration.y,a.acceleration.z)*180.0f/PI;
 float pitch=atan2f(-a.acceleration.x,sqrtf(a.acceleration.y*a.acceleration.y+
                a.acceleration.z*a.acceleration.z))*180.0f/PI;
 Serial.printf("%lu,%.2f,%.2f,%.3f\n",(unsigned long)now,roll,pitch,g.gyro.x);
 // Tilt estimate is meaningful here under quasi-static conditions. gyro is rad/s.
}
