#include <Arduino.h>
#include "course_pwm.h"
CoursePwm led(23,0);uint32_t last=0;
void setup(){Serial.begin(115200);analogReadResolution(12);
  if(!led.begin(1000,8)){Serial.println("PWM SETUP FAILED");while(true)delay(100);}}
void loop(){uint32_t now=millis();if(uint32_t(now-last)<50)return;last=now;
  uint32_t raw=analogRead(34);uint32_t duty=(raw*255UL)/4095UL;
  led.write(duty);Serial.printf("%lu,%lu,%lu\n",(unsigned long)now,
    (unsigned long)raw,(unsigned long)duty);
}
