#include <Arduino.h>
// ESP32-WROOM reference. ECHO must be level-adapted for physical hardware.
constexpr uint8_t TRIG=17,ECHO=16;uint32_t last=0;
void setup(){Serial.begin(115200);pinMode(TRIG,OUTPUT);digitalWrite(TRIG,LOW);
  pinMode(ECHO,INPUT);}
void loop(){uint32_t now=millis();if(uint32_t(now-last)<100)return;last=now;
  digitalWrite(TRIG,LOW);delayMicroseconds(2);digitalWrite(TRIG,HIGH);
  delayMicroseconds(10);digitalWrite(TRIG,LOW);
  // Bounded blocking call: it can still take up to 25 ms.
  unsigned long us=pulseIn(ECHO,HIGH,25000UL);
  if(us==0){Serial.printf("%lu,INVALID\n",(unsigned long)now);return;}
  float cm=us*0.0343f/2.0f;
  Serial.printf("%lu,%.2f\n",(unsigned long)now,cm);
}
