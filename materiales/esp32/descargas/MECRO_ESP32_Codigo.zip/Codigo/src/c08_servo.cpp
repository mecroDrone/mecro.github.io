#include <Arduino.h>
#include "course_pwm.h"
CoursePwm servo(13,0);uint32_t last=0;
void setup(){Serial.begin(115200);analogReadResolution(12);
  if(!servo.begin(50,16)){Serial.println("PWM SETUP FAILED");while(true)delay(100);}}
void loop(){uint32_t now=millis();if(uint32_t(now-last)<20)return;last=now;
  // Exercise envelope; verify the servo manufacturer's allowed pulse range.
  uint32_t us=1100UL+(analogRead(34)*800UL)/4095UL;
  uint32_t duty=(us*65535UL)/20000UL;servo.write(duty);
  static uint32_t logAt=0;if(uint32_t(now-logAt)>=100){logAt=now;
    Serial.printf("%lu,%lu\n",(unsigned long)now,(unsigned long)us);}
}
