#include <Arduino.h>
#include "course_pwm.h"
CoursePwm motor(25,0);constexpr uint8_t IN1=26,IN2=27;
uint32_t commandAt=0;uint8_t duty=0;
void stop(){duty=0;motor.write(0);digitalWrite(IN1,LOW);digitalWrite(IN2,LOW);}
void setup(){Serial.begin(115200);pinMode(IN1,OUTPUT);pinMode(IN2,OUTPUT);
  if(!motor.begin(1000,8)){while(true)delay(100);}stop();
  Serial.println("BENCH: + increments, - decrements, s stops; command expires in 2 s");}
void loop(){uint32_t now=millis();
  while(Serial.available()){char c=Serial.read();
    if(c=='+'){duty=uint8_t(min(160,int(duty)+20));commandAt=now;}
    else if(c=='-'){duty=uint8_t(max(0,int(duty)-20));commandAt=now;}
    else if(c=='s'){stop();commandAt=now;}
  }
  if(uint32_t(now-commandAt)>2000)stop();
  digitalWrite(IN1,duty>0);digitalWrite(IN2,LOW);motor.write(duty);
}
