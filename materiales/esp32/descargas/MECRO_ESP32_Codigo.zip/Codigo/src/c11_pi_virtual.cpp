#include <Arduino.h>
// Synthetic first-order teaching plant. No motor or ESC output.
float rpm=0,integral=0,simTime=0;uint32_t last=0;const float DT=0.02f;
void setup(){Serial.begin(115200);Serial.println("t_s,ref_rpm,rpm,u_pwm,load_rpm");}
void loop(){uint32_t now=millis();if(uint32_t(now-last)<20)return;last=now;
 float t=simTime;simTime+=DT;float ref=t<1?0:500,load=t<4?0:100;
 float error=ref-rpm;float trial=integral+0.6f*error*DT;
 float unsat=ref/4.0f+0.12f*error+trial;
 if((unsat>=0 && unsat<=255)||(unsat>255 && error<0)||(unsat<0 && error>0))integral=trial;
 float u=constrain(ref/4.0f+0.12f*error+integral,0.0f,255.0f);
 rpm+=DT*(max(0.0f,4.0f*u-load)-rpm)/0.35f;
 Serial.printf("%.2f,%.1f,%.1f,%.1f,%.1f\n",t,ref,rpm,u,load);
}
