#include <Arduino.h>
constexpr uint8_t BTN=18,LED=23;
bool rawPrevious=HIGH,stable=HIGH;
uint32_t changed=0;
void setup(){Serial.begin(115200);pinMode(BTN,INPUT_PULLUP);pinMode(LED,OUTPUT);}
void loop(){
  uint32_t now=millis();bool raw=digitalRead(BTN);
  if(raw!=rawPrevious){rawPrevious=raw;changed=now;}
  if(uint32_t(now-changed)>=25 && raw!=stable){
    stable=raw;digitalWrite(LED,stable==LOW);
    Serial.println(stable==LOW?"PRESS":"RELEASE");
  }
}
