#include <Arduino.h>
constexpr uint8_t R=23,Y=22,G=21,BTN=18;
enum class State:uint8_t {RED,GREEN,YELLOW};
State state=State::RED;uint32_t since=0;bool request=false;
void enter(State next,uint32_t now){
  state=next;since=now;
  digitalWrite(R,state==State::RED);digitalWrite(G,state==State::GREEN);
  digitalWrite(Y,state==State::YELLOW);
}
void setup(){Serial.begin(115200);pinMode(R,OUTPUT);pinMode(Y,OUTPUT);
  pinMode(G,OUTPUT);pinMode(BTN,INPUT_PULLUP);enter(State::RED,millis());}
void loop(){uint32_t now=millis();
  if(digitalRead(BTN)==LOW)request=true;
  if(state==State::RED && uint32_t(now-since)>=3000)enter(State::GREEN,now);
  else if(state==State::GREEN && uint32_t(now-since)>=3000)enter(State::YELLOW,now);
  else if(state==State::YELLOW && uint32_t(now-since)>=1000){
    enter(State::RED,now);Serial.println(request?"REQUEST SERVED":"RED");request=false;}
}
