# Código docente MECRO · ESP32 clásico

Este proyecto contiene catorce ejemplos completos para las lecturas del curso.

## Abrir y elegir un ejemplo

1. Extraer la carpeta Codigo en una ruta corta y abrirla con VS Code + PlatformIO.
2. Conservar platformio.ini e include/course_pwm.h. Cada entorno selecciona un solo archivo .cpp.
3. En las tareas de PlatformIO elegir el entorno de la clase y ejecutar Build.
4. Identificar la placa física, revisar cableado y alimentación; después elegir Upload.
5. Abrir el monitor serie a 115200. Compilar y observar son comprobaciones distintas.

También se puede elegir un entorno con: pio run -e c01_led
Para cargarlo: pio run -e c01_led -t upload

En Windows se recomienda extraer en una ruta corta para evitar límites de longitud de rutas del compilador.

## Entorno de referencia comprobado

PlatformIO Core 6.1.18; plataforma espressif32@6.9.0; framework Arduino-ESP32 2.0.17;
board esp32dev; Adafruit MPU6050 2.2.6; Unified Sensor 1.1.14; BusIO 1.16.1.
Los catorce entornos compilaron correctamente el 22/10/2026.
La rama de compatibilidad LEDC para Arduino-ESP32 3.x está incluida, pero no se compiló aquí.
No se adjuntan pruebas de ejecución física. Antes de la docencia, verificar cada banco real.

## Ejemplos y conexiones

| Entorno | Función | Referencia de conexión |
| --- | --- | --- |
| c01_led | LED temporizado | GPIO23, resistor y LED a GND |
| c02_boton | Pulsación con rebote y evento | Botón GPIO18 a GND con INPUT_PULLUP; LED23 |
| c03_estados | Máquina de estados | LED23; pulsador18 a GND |
| c04_adc | Lectura ADC e histéresis | Entrada ADC1 GPIO34; señal dentro de límites |
| c05_pwm | LED con PWM y cabecera de compatibilidad | LED23 con resistor |
| c07_distancia | HC-SR04 con timeout | WROOM: TRIG17, ECHO16 adaptado a 3,3 V; alimentación del módulo |
| c08_servo | Pulsos de servo | Señal13; fuente del servo separada y retorno común |
| c09_motor | Mando PWM de motor DC | EN25, IN1=26, IN2=27; driver, fuente y motor del banco |
| c10_encoder | Conteo en interrupción y RPM | Señal A32; referencia y nivel revisados; N efectivo por confirmar |
| c11_pi_virtual | Comparación P/PI en planta virtual | Solo consola; tiempo de modelo, no motor real |
| c12_imu | Roll/pitch estáticos y giro | MPU6050 en I2C SDA21/SCL22, dirección0x68 |
| c13_mando | Normalización de mando | Entradas analógicas34/35; no acciona ESC |
| c14_wifi | Servidor /datos y consulta de calendario | ADC34; SSID/clave del ejemplo se adaptan a red física |
| c15_integrador | Estación IMU con estado y dato válido | I2C21/22; LED23; ADC34; botón18 reservado a ampliación |

## Condiciones del banco

ESP32 clásico no identifica una única placa comercial. Comprobar módulo, memoria, pines y alimentación.
El perfil GPIO16/17 del HC-SR04 supone un WROOM sin reserva de esos pines; no copiarlo a módulos con PSRAM.
HC-SR04: adaptar ECHO de 5 V; la lectura explica el divisor de ejemplo. No conectar una señal de 5 V al GPIO.
Servo: 1100–1900 us es el intervalo del ejercicio, no una especificación universal de ángulo.
Motor: el programa c09 inicia parado, limita el mando y lo vence tras dos segundos sin orden. Las órdenes
por consola son +, - y s. Utilizar el driver y la fuente del banco revisados; no alimentar un motor desde GPIO.
Encoder: veinte cuentas por vuelta es un parámetro de aula. Medirlo según eje, flanco y reductora reales.
El integrador verifica presencia I2C, finitud, plausibilidad y edad bajo un criterio de aula. No certifica la
orientación ni cubre todas las averías. La prueba de muestra vencida puede hacerse mediante inyección
controlada por software. Si la inicialización falla, este ejemplo requiere reiniciar tras corregir el banco.
Wi-Fi: Wokwi permite tráfico saliente; un servidor entrante requiere gateway apropiado o hardware local.
Bluetooth es una extensión física; no se adjunta un ejemplo BLE que se anuncie simulado en Wokwi.
NTP: time(nullptr) debe interpretarse solo después de comprobar sincronización/validez. No es un reloj
atómico local. millis() es la referencia para intervalos del programa.

## Uso con Wokwi

Las lecturas enlazan los proyectos originales de MECRO. Para probar estos archivos nuevos, crear una copia
del proyecto correspondiente, usar una placa clásica compatible y adaptar su sketch/bibliotecas/pinout.
Los archivos .cpp son proyectos PlatformIO: para usarlos como sketch Arduino/Wokwi se conserva un único
ejemplo y se adjunta course_pwm.h donde se utilice. No basta arrastrar toda la carpeta src a un solo sketch.
El paquete no afirma que los veinte simuladores web hayan sido ejecutados nuevamente.
